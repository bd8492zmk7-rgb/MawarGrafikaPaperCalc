MawarGrafikaPaperCalc - Flutter project
=====================================

Isi paket ini:
- lib/main.dart       : kode utama aplikasi
- pubspec.yaml        : dependensi (shared_preferences)
- assets/mawar_bg.jpeg: gambar background (as supplied)
- README.md

Instruksi singkat build:
1. Pasang Flutter SDK & Android Studio.
2. Ekstrak ZIP ini.
3. Buka folder proyek di Android Studio atau VS Code.
4. Jalankan `flutter pub get`.
5. Untuk debug APK: `flutter build apk --debug`.
6. Untuk release, ikuti panduan signing Flutter: https://docs.flutter.dev/deployment/android

Catatan:
- Aplikasi dikunci ke orientasi portrait lewat kode (SystemChrome).
- Icon launcher belum otomatis diganti — untuk icon gunakan package flutter_launcher_icons atau ganti di Android/iOS native jika perlu.
- Background gambar dipakai dengan resolusi asli sesuai permintaan.