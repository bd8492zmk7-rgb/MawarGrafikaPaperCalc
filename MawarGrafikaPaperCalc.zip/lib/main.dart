import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Lock to portrait
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const PaperCalcApp());
}

class PaperCalcApp extends StatelessWidget {
  const PaperCalcApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kalkulator Potong Kertas - Mawar Grafika',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1800), () {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const HomePage()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset('assets/mawar_bg.jpeg', fit: BoxFit.cover),
          Container(color: Colors.black.withOpacity(0.25)),
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: const [
                Icon(Icons.print, size: 72, color: Colors.white),
                SizedBox(height: 12),
                Text('Mawar Grafika',
                    style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                Text('Kalkulator Potong Kertas', style: TextStyle(color: Colors.white70)),
              ],
            ),
          ),
          Positioned(
            bottom: 18,
            left: 0,
            right: 0,
            child: Center(
              child: Text('Created by Yayang Oky', style: TextStyle(color: Colors.white.withOpacity(0.85))),
            ),
          )
        ],
      ),
    );
  }
}

class Preset {
  String name;
  double bigW;
  double bigH;
  double cutW;
  double cutH;
  int gsm;
  Preset({
    required this.name,
    required this.bigW,
    required this.bigH,
    required this.cutW,
    required this.cutH,
    required this.gsm,
  });

  Map<String, dynamic> toJson() => {
        'name': name,
        'bigW': bigW,
        'bigH': bigH,
        'cutW': cutW,
        'cutH': cutH,
        'gsm': gsm,
      };

  static Preset fromJson(Map<String, dynamic> j) => Preset(
        name: j['name'],
        bigW: (j['bigW'] as num).toDouble(),
        bigH: (j['bigH'] as num).toDouble(),
        cutW: (j['cutW'] as num).toDouble(),
        cutH: (j['cutH'] as num).toDouble(),
        gsm: (j['gsm'] as num).toInt(),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController bigW = TextEditingController(text: '65');
  final TextEditingController bigH = TextEditingController(text: '100');
  final TextEditingController cutW = TextEditingController(text: '31');
  final TextEditingController cutH = TextEditingController(text: '50');
  final TextEditingController gsmC = TextEditingController(text: '120');
  final TextEditingController needCount = TextEditingController(text: '1000');

  String unit = 'cm';
  int perSheet = 0;
  String bestOrientation = '';
  double remW = 0;
  double remH = 0;

  // pack config fixed 100
  final int perPack = 100;
  int needSheets = 0;
  int needPacks = 0;
  int leftoverSheets = 0;

  List<Preset> presets = [];
  SharedPreferences? prefs;

  @override
  void initState() {
    super.initState();
    _loadPresets();
  }

  Future<void> _loadPresets() async {
    prefs = await SharedPreferences.getInstance();
    final String? raw = prefs!.getString('presets_v1');
    if (raw != null) {
      try {
        final List<dynamic> arr = jsonDecode(raw);
        presets = arr.map((e) => Preset.fromJson(e)).toList();
        setState(() {});
      } catch (e) {
        // ignore
      }
    }
  }

  Future<void> _savePresets() async {
    if (prefs == null) prefs = await SharedPreferences.getInstance();
    final String raw = jsonEncode(presets.map((p) => p.toJson()).toList());
    await prefs!.setString('presets_v1', raw);
  }

  void calculateAll() {
    final double BW = double.tryParse(bigW.text.replaceAll(',', '.')) ?? 0;
    final double BH = double.tryParse(bigH.text.replaceAll(',', '.')) ?? 0;
    final double CW = double.tryParse(cutW.text.replaceAll(',', '.')) ?? 0;
    final double CH = double.tryParse(cutH.text.replaceAll(',', '.')) ?? 0;

    if (BW <= 0 || BH <= 0 || CW <= 0 || CH <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Masukkan ukuran valid (>0).')));
      return;
    }

    final int cols1 = (BW / CW).floor();
    final int rows1 = (BH / CH).floor();
    final int total1 = cols1 * rows1;
    final double remW1 = BW - cols1 * CW;
    final double remH1 = BH - rows1 * CH;

    final int cols2 = (BW / CH).floor();
    final int rows2 = (BH / CW).floor();
    final int total2 = cols2 * rows2;
    final double remW2 = BW - cols2 * CH;
    final double remH2 = BH - rows2 * CW;

    // simple strip fit extras
    int extra1 = _fitInStrips(BW, BH, CW, CH, cols1, rows1);
    int extra2 = _fitInStrips(BW, BH, CH, CW, cols2, rows2);

    final int improved1 = total1 + extra1;
    final int improved2 = total2 + extra2;

    setState(() {
      if (improved2 > improved1) {
        perSheet = improved2;
        bestOrientation = 'Diputar 90°';
        remW = remW2;
        remH = remH2;
      } else {
        perSheet = improved1;
        bestOrientation = 'Tanpa putar';
        remW = remW1;
        remH = remH1;
      }
    });

    // packs calculation
    final int desired = int.tryParse(needCount.text.replaceAll(',', '.')) ?? 0;
    if (desired <= 0) {
      setState(() {
        needSheets = 0;
        needPacks = 0;
        leftoverSheets = 0;
      });
      return;
    }
    // how many small pieces from one sheet = perSheet
    if (perSheet <= 0) {
      setState(() {
        needSheets = 0;
        needPacks = 0;
        leftoverSheets = 0;
      });
      return;
    }
    // sheets needed (ceil)
    int sheetsNeeded = (desired / perSheet).ceil();
    int packs = sheetsNeeded ~/ perPack;
    int rem = sheetsNeeded % perPack;
    setState(() {
      needSheets = sheetsNeeded;
      needPacks = packs;
      leftoverSheets = rem;
    });
  }

  int _fitInStrips(double BW, double BH, double CW, double CH, int cols, int rows) {
    int extra = 0;
    final double usedW = cols * CW;
    final double usedH = rows * CH;
    final double leftW = BW - usedW;
    final double leftH = BH - usedH;

    if (leftW >= min(CW, CH)) {
      final int fit1 = (leftW / CW).floor() * (BH / CH).floor();
      final int fit2 = (leftW / CH).floor() * (BH / CW).floor();
      extra += max(fit1, fit2);
    }
    if (leftH >= min(CW, CH)) {
      final int fit1 = (BW / CW).floor() * (leftH / CH).floor();
      final int fit2 = (BW / CH).floor() * (leftH / CW).floor();
      extra += max(fit1, fit2);
    }
    return extra;
  }

  void _savePresetDialog() {
    showDialog(
      context: context,
      builder: (ctx) {
        final nameCtrl = TextEditingController();
        return AlertDialog(
          title: const Text('Simpan Preset'),
          content: TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Nama preset')),
          actions: [
            TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Batal')),
            ElevatedButton(
                onPressed: () {
                  final String name = nameCtrl.text.trim();
                  if (name.isEmpty) return;
                  final p = Preset(
                      name: name,
                      bigW: double.tryParse(bigW.text.replaceAll(',', '.')) ?? 0,
                      bigH: double.tryParse(bigH.text.replaceAll(',', '.')) ?? 0,
                      cutW: double.tryParse(cutW.text.replaceAll(',', '.')) ?? 0,
                      cutH: double.tryParse(cutH.text.replaceAll(',', '.')) ?? 0,
                      gsm: int.tryParse(gsmC.text) ?? 0);
                  presets.add(p);
                  _savePresets();
                  setState(() {});
                  Navigator.of(ctx).pop();
                },
                child: const Text('Simpan')),
          ],
        );
      },
    );
  }

  void _applyPreset(Preset p) {
    bigW.text = p.bigW.toString();
    bigH.text = p.bigH.toString();
    cutW.text = p.cutW.toString();
    cutH.text = p.cutH.toString();
    gsmC.text = p.gsm.toString();
    setState(() {});
    calculateAll();
  }

  void _editPresetDialog(int idx) {
    final p = presets[idx];
    showDialog(
      context: context,
      builder: (ctx) {
        final nameCtrl = TextEditingController(text: p.name);
        return AlertDialog(
          title: const Text('Edit Preset'),
          content: TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Nama preset')),
          actions: [
            TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Batal')),
            ElevatedButton(
                onPressed: () {
                  p.name = nameCtrl.text.trim();
                  _savePresets();
                  setState(() {});
                  Navigator.of(ctx).pop();
                },
                child: const Text('Simpan')),
          ],
        );
      },
    );
  }

  void _deletePreset(int idx) {
    presets.removeAt(idx);
    _savePresets();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context).size;
    return Scaffold(
      body: Stack(
        children: [
          Image.asset('assets/mawar_bg.jpeg', fit: BoxFit.cover, width: double.infinity, height: double.infinity),
          Container(color: Colors.white.withOpacity(0.14)),
          SafeArea(
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  children: [
                    // visual area
                    SizedBox(
                      height: media.height * 0.32,
                      child: Card(
                        color: Colors.white.withOpacity(0.9),
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: LayoutBuilder(builder: (context, constraints) {
                            final double BW = double.tryParse(bigW.text.replaceAll(',', '.')) ?? 0;
                            final double BH = double.tryParse(bigH.text.replaceAll(',', '.')) ?? 0;
                            final double CW = double.tryParse(cutW.text.replaceAll(',', '.')) ?? 0;
                            final double CH = double.tryParse(cutH.text.replaceAll(',', '.')) ?? 0;
                            return CustomPaint(
                              size: Size(constraints.maxWidth, constraints.maxHeight),
                              painter: PaperPainter(BW, BH, CW, CH),
                            );
                          }),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    // inputs & side results
                    Card(
                      color: Colors.white.withOpacity(0.85),
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Column(children: [
                          Row(children: [
                            Expanded(child: _numField('Lebar kertas besar', bigW, 'cm')),
                            const SizedBox(width: 8),
                            Expanded(child: _numField('Tinggi kertas besar', bigH, 'cm')),
                          ]),
                          const SizedBox(height: 8),
                          Row(children: [
                            Expanded(child: _numField('Lebar potongan', cutW, 'cm')),
                            const SizedBox(width: 8),
                            Expanded(child: _numField('Tinggi potongan', cutH, 'cm')),
                          ]),
                          const SizedBox(height: 8),
                          Row(children: [
                            Expanded(child: _numField('Ketebalan kertas (GSM)', gsmC, '')),
                            const SizedBox(width: 8),
                            Expanded(child: _numField('Jumlah potongan dibutuhkan', needCount, '')),
                          ]),
                          const SizedBox(height: 8),
                          Row(children: [
                            ElevatedButton.icon(onPressed: calculateAll, icon: const Icon(Icons.calculate), label: const Text('Hitung')),
                            const SizedBox(width: 8),
                            ElevatedButton.icon(onPressed: _savePresetDialog, icon: const Icon(Icons.save), label: const Text('Simpan preset')),
                            const SizedBox(width: 8),
                            ElevatedButton.icon(onPressed: () { setState(() {
                              bigW.text = '65'; bigH.text = '100'; cutW.text='31'; cutH.text='50'; gsmC.text='120'; needCount.text='1000';
                            }); }, icon: const Icon(Icons.refresh), label: const Text('Reset')),
                            const Spacer(),
                            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                              Text('Potongan / lembar: $perSheet', style: const TextStyle(fontWeight: FontWeight.bold)),
                              Text('Orientasi: $bestOrientation'),
                              Text('Sisa per lembar: ${remW.toStringAsFixed(2)} × ${remH.toStringAsFixed(2)} $unit'),
                            ])
                          ]),
                          const SizedBox(height: 6),
                          # packs result (side)
                          Row(children: [
                            Expanded(child: Text('Kebutuhan lembar besar: $needSheets')),
                            const SizedBox(width: 8),
                            Expanded(child: Text('Kebutuhan pack: ${needPacks} pack + ${leftoverSheets} lembar')),
                          ]),
                        ]),
                      ),
                    ),
                    const SizedBox(height: 10),
                    # presets list
                    Card(
                      color: Colors.white.withOpacity(0.85),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(children: [
                          Row(children: const [Text('Preset ukuran tersimpan', style: TextStyle(fontWeight: FontWeight.bold)), Spacer(),]),
                          const SizedBox(height: 8),
                          if (presets.isEmpty) const Text('Belum ada preset tersimpan.'),
                          for (int i = 0; i < presets.length; i++)
                            ListTile(
                              tileColor: Colors.white70,
                              title: Text(presets[i].name),
                              subtitle: Text('${presets[i].bigW}×${presets[i].bigH} → ${presets[i].cutW}×${presets[i].cutH}  (GSM ${presets[i].gsm})'),
                              trailing: Wrap(spacing: 6, children: [
                                IconButton(onPressed: () => _applyPreset(presets[i]), icon: const Icon(Icons.play_arrow)),
                                IconButton(onPressed: () => _editPresetDialog(i), icon: const Icon(Icons.edit)),
                                IconButton(onPressed: () => _deletePreset(i), icon: const Icon(Icons.delete)),
                              ]),
                            )
                        ]),
                      ),
                    ),
                    const SizedBox(height: 18),
                    # watermark
                    Align(
                      alignment: Alignment.bottomRight,
                      child: Padding(
                        padding: const EdgeInsets.only(right: 6.0, bottom: 6.0),
                        child: Text('Yayang Oky', style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 12)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _numField(String label, TextEditingController ctrl, String suffix) {
    return TextField(
      controller: ctrl,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: InputDecoration(labelText: label, suffixText: suffix, border: const OutlineInputBorder()),
    );
  }
}

class PaperPainter extends CustomPainter {
  final double BW, BH, CW, CH;
  PaperPainter(this.BW, this.BH, this.CW, this.CH);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;

    if (BW <= 0 || BH <= 0 || CW <= 0 || CH <= 0) {
      final tp = TextPainter(text: const TextSpan(text: 'Masukkan ukuran dan tekan Hitung', style: TextStyle(color: Colors.black)), textDirection: TextDirection.ltr);
      tp.layout(maxWidth: size.width);
      tp.paint(canvas, const Offset(10, 10));
      return;
    }

    # scale to fit inside size
    final double scaleX = size.width / BW;
    final double scaleY = size.height / BH;
    final double scale = min(scaleX, scaleY) * 0.95;
    final double offsetX = (size.width - BW * scale) / 2;
    final double offsetY = (size.height - BH * scale) / 2;

    # draw big rect
    paint.color = Colors.black;
    final rect = Rect.fromLTWH(offsetX, offsetY, BW * scale, BH * scale);
    canvas.drawRect(rect, paint);

    # draw grid without considering strip extras (simple grid)
    # choose orientation based on whichever packs more
    final int cols1 = (BW / CW).floor();
    final int rows1 = (BH / CH).floor();
    final int total1 = cols1 * rows1;

    final int cols2 = (BW / CH).floor();
    final int rows2 = (BH / CW).floor();
    final int total2 = cols2 * rows2;

    bool useRotated = total2 > total1;
    double w = useRotated ? CH : CW;
    double h = useRotated ? CW : CH;

    # draw cells
    paint.color = Colors.blue.shade700;
    for (int i = 0; i < (BW / w).floor(); i++) {
      for (int j = 0; j < (BH / h).floor(); j++) {
        final r = Rect.fromLTWH(offsetX + i * w * scale, offsetY + j * h * scale, w * scale, h * scale);
        canvas.drawRect(r, paint);
        # draw label
        final tp = TextPainter(
          text: TextSpan(text: '${w.toStringAsFixed(0)}×${h.toStringAsFixed(0)}', style: const TextStyle(color: Colors.black, fontSize: 10)),
          textDirection: TextDirection.ltr,
        );
        tp.layout(maxWidth: r.width - 4);
        tp.paint(canvas, Offset(r.left + 4, r.top + 4));
      }
    }

    # draw leftover area
    final usedW = (BW / w).floor() * w;
    final usedH = (BH / h).floor() * h;
    final leftW = BW - usedW;
    final leftH = BH - usedH;
    final leftoverPaint = Paint()..color = Colors.pink.withOpacity(0.25);
    if (leftW > 0.001) {
      final lr = Rect.fromLTWH(offsetX + usedW * scale, offsetY, leftW * scale, BH * scale);
      canvas.drawRect(lr, leftoverPaint);
    }
    if (leftH > 0.001) {
      final lr = Rect.fromLTWH(offsetX, offsetY + usedH * scale, BW * scale, leftH * scale);
      canvas.drawRect(lr, leftoverPaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
